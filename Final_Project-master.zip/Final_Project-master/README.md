# Final_Project

<b>Team Members:</b> Eric Litz, Algis Grybauskas, AJ Peters, Bryce Davis

<b>Problem:</b> How can we use Machine Learning algorithms to predict commute time in a city in 2018. We currently have a dataset with commute times from 2009-2017.  

<b>Dataset:</b>
<ul> 
<li>https://factfinder.census.gov/bkmk/table/1.0/en/ACS/16_5YR/GCT0801.US22PR </li>
<li>Data in the Chicagoland area</li>
</ul>

<b>Tools:</b>
<ul>
  <li> ML Library (TBD) </li>
  <li> Pandas </li>
  <li> Tableau </li>
  <li> Matplotlib </li>
</ul>

<b> Process: </b> 
<ul>
  <li> Extract Chicagoland data from census.gov into a .csv </li>
<li>Transform data using Pandas </li>
<li>Use an ML library to train and test annual average commute times between 2009-2017 </li>
<li>Use model to see how closely we can predict 2018 commute times </li>
<li>Load and visualize the following in Tableau: </li>
<li>Average commute time by area </li>
<li>Average commute time by year </li>
<li>Predicted 2018 vs. Actual 2018 </li>
<li>Leverage Matplotlib for further visualization </li>
  <li> <b> If time permits: </b> </li>
  <ol>
<li>Apply the process above to additional metro areas </li>
<li>Embed Tableau charts into HTML and deploy through Heroku </li>
<li>Overlay commute time dataset with commute distance dataset </li>
<li>Dataset Link: https://www.census.gov/data/tables/2015/demo/metro-micro/commuting-flows-2015.html (table 3) </li>
  </ol>
</ul>


Possible Data Set to use: https://data.cityofchicago.org/Transportation/Traffic-Crashes-Crashes/85ca-t3if (traffic collisions) 
https://data.cityofchicago.org/Transportation/Transportation-Network-Providers-Trips/m6dm-c72p (rideshare trips)
